function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5sqVh3RQjeA":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

